name = "abcd-macd"

__version__ = "0.0.1"

from abcd import *
