# abcd

A Python wrapper around, and a few tests for, the Berkeley ABC logic
synthesis and verification program.

This is still just a quick hack.  The library _abcd.so is already
compiled, compressed, and stuffed into the abcd directory, so you will
need to manually decompress it for this to work.

WARNING: This was build and compiled for Anaconda Python 3.8.5 and
almost surely will not work with other versions. You will have to
clone a copy of https://github.com/Berkeley-abc/abc then copy the file
abcd.i to the abc/src directory and follow the instructions in abcd.i
file in order to build a version _abcd.so that is compatible with your
Python version.

If you do have Anaconda Python 3.8.5, then you can clone this repo and
install it as an 'editable' package by

    pip install -e abcd

Finally, it's called abcd rather than abc because swig will generate
a function call Abc_Init which clashes with an internal abc function
name.
