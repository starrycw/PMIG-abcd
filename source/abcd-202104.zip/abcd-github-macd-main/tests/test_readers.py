from os.path import split
import abcd

PREFIX = split(abcd.__file__)[0] + "/../tests/designs"

abc = abcd.abc_start()

def test_c1355():
    status, msg = abc(f"read_aiger {PREFIX}/c1355.aiger")
    if status != 0:
        print(msg)
    assert status == 0

    
def test_c2670():
    status, msg = abc(f"read_aiger {PREFIX}/c2670.aiger")
    if status != 0:
        print(msg)
    assert status == 0


def test_pipe_no():
    status, msg = abc(f"read_aiger {PREFIX}/pipe_mult_64_noabc.aiger")
    if status != 0:
        print(msg)
    assert status == 0


def test_pipe():
    status, msg = abc(f"read_aiger {PREFIX}/pipe_mult.aiger")
    if status != 0:
        print(msg)
    assert status == 0


def test_sin():
    status, msg = abc(f"read_aiger {PREFIX}/sin.aiger")
    if status != 0:
        print(msg)
    assert status == 0


def test_bk_adder_32():
    status, msg = abc(f"read_blif {PREFIX}/bk_adder_32.blif")
    if status != 0:
        print(msg)
    assert status == 0

def test_bk_adder_64():
    status, msg = abc(f"read_blif {PREFIX}/bk_adder_64.blif")
    if status != 0:
        print(msg)
    assert status == 0

def test_bk_adder_8():
    status, msg = abc(f"read_blif {PREFIX}/bk_adder_8.blif")
    if status != 0:
        print(msg)
    assert status == 0
    
def test_cla_32():
    status, msg = abc(f"read_blif {PREFIX}/cla_32.blif")
    if status != 0:
        print(msg)
    assert status == 0
    
def test_cla_64():
    status, msg = abc(f"read_blif {PREFIX}/cla_64.blif")
    if status != 0:
        print(msg)
    assert status == 0

def cla_8():
    status, msg = abc(f"read_blif {PREFIX}/cla_8.blif")
    if status != 0:
        print(msg)
    assert status == 0
    
def test_pipe_mult_64():
    status, msg = abc(f"read_blif {PREFIX}/pipe_mult_64.blif")
    if status != 0:
        print(msg)
    assert status == 0
    
def test_pipe_mult_64_noabc():
    status, msg = abc(f"read_blif {PREFIX}/pipe_mult_64_noabc.blif")
    if status != 0:
        print(msg)
    assert status == 0
    
def test_pipe_mult():
    status, msg = abc(f"read_blif {PREFIX}/pipe_mult.blif")
    if status != 0:
        print(msg)
    assert status == 0
    
def test_reg_mult_4():
    status, msg = abc(f"read_blif {PREFIX}/reg_mult_4.blif")
    if status != 0:
        print(msg)
    assert status == 0
    
def test_ripple_32():
    status, msg = abc(f"read_blif {PREFIX}/ripple_32.blif")
    if status != 0:
        print(msg)
    assert status == 0
    
def test_ripple_64():
    status, msg = abc(f"read_blif {PREFIX}/ripple_64.blif")
    if status != 0:
        print(msg)
    assert status == 0
    
def test_ripple_8():
    status, msg = abc(f"read_blif {PREFIX}/ripple_8.blif")
    if status != 0:
        print(msg)
    assert status == 0
    
def test_sin():
    status, msg = abc(f"read_blif {PREFIX}/sin.blif")
    if status != 0:
        print(msg)
    assert status == 0
    
def test_ys_mult_64():
    status, msg = abc(f"read_blif {PREFIX}/ys_mult_64.blif")
    if status != 0:
        print(msg)
    assert status == 0
    
